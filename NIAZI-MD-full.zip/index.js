/**
 * index.js - NIAZI-MD full scaffold (pair-code)
 * This is a placeholder main file that starts a Baileys socket and exposes simple pairing outputs.
 * Edit and extend as required.
 */
const express = require('express');
const fs = require('fs');
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@adiwajshing/baileys');
const qrcode = require('qrcode-terminal');
const config = require('./config');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));
app.get('/', (req, res) => res.send('NIAZI-MD bot scaffold running. Visit /pair.html after copying pairing payload.'));

async function startBot(){
  const { state, saveCreds } = await useMultiFileAuthState(`./session/${config.SESSION_ID}`);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({ printQRInTerminal: true, auth: state, version });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if(qr){
      console.log('--- PAIRING PAYLOAD (paste into pair.html) ---');
      console.log(qr);
      qrcode.generate(qr, { small: true });
      // Also save to a file so you can copy to pair.html on hosting
      fs.writeFileSync('./public/pair-payload.txt', qr);
    }
    if(connection === 'open'){
      console.log('Connected as NIAZI-MD');
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('messages.upsert', async (m) => {
    // minimal handler
    try{
      const msgs = m.messages || [];
      for(const msg of msgs){
        if(!msg.message || msg.key.fromMe) continue;
        const from = msg.key.remoteJid;
        const text = msg.message.conversation || (msg.message.extendedTextMessage && msg.message.extendedTextMessage.text) || '';
        console.log('msg from', from, text);
        if(text.toLowerCase().includes('owner')){
          await sock.sendMessage(from, { text: `Owner: ${config.OWNER_NAME} (${config.OWNER_NUMBER})` });
        }
      }
    }catch(e){
      console.error('msg handler err', e);
    }
  });
}

startBot().catch(e => {
  console.error('Start error', e);
});

app.listen(PORT, ()=>console.log('Webserver on', PORT));
