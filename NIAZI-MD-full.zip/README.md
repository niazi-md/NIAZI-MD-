# NIAZI-MD Full Scaffold

Ye ek fuller scaffold hai jo zyada folders aur example files rakhta hai (placeholders). Aap apni original repository ki files yahan daal kar replace kar sakte ho — main phir content replace kar dunga.

Key files:
- pair.html (in root and src/) - browser QR renderer
- public/pair-payload.txt - auto-updated when pairing payload appears
- session/ - where credentials will be stored locally (ignored in .gitignore)
- commands/ plugins/ lib/ - placeholder folders for your bot code
