module.exports = {
  OWNER_NAME: "NIAZI-MD",
  OWNER_NUMBER: "+92 344 8166105",
  GROUP_LINK: "https://chat.whatsapp.com/KJ6qs3H2xC6AQPYRTaNBNm?mode=wwt",
  CHANNEL_LINK: "https://whatsapp.com/channel/0029VbBKWrA2v1Iu4KVE3A1H",
  PROFILE_IMAGE: "https://i.ibb.co/gbbGmx3G/shaban-md.jpg",
  SESSION_ID: process.env.SESSION_ID || "niazi-md"
};
