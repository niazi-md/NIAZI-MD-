module.exports = {
  name: 'owner',
  description: 'Send owner contact',
  execute: async (sock, msg) => {
    await sock.sendMessage(msg.key.remoteJid, { text: 'Owner: NIAZI-MD (+92 344 8166105)' });
  }
};
