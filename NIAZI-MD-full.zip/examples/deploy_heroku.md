Heroku deploy steps:
1. git init
2. git add .
3. git commit -m 'init'
4. heroku create
5. git push heroku main
Set SESSION_ID env var if needed.